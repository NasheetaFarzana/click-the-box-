# click-the-box-
its a basic game that i had created in which you need to click on the box whenever it changes its place  and score within the given time
